fun main(){

    val choice = arrayOf<String>("Gunting","Batu","Kertas")

    print("Player 1 : ")
    val input1:String? = readLine()
    print("Player 2 : ")
    val input2:String? = readLine()

    if(input1 == input2){
        println("Seri")
    }else{
        for (i in 0..2){
            var j = i+1
            if (j>2){
                j=0
            }
            when(input1) {
                choice[i] ->
                    if (input2 == choice[j]) {
                        println("Result : Player 2 Menang")
                    } else {
                        println("Result : Player 1 Menang")
                    }
            }
        }
    }




}